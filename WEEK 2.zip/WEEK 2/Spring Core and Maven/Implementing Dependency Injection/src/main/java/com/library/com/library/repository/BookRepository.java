package com.library.repository;

public class BookRepository {
    // Simple implementation for demonstration
}
