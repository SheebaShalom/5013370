package com.library;

import com.library.model.Book;
import com.library.service.BookService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class LibraryManagementApplication {

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        BookService bookService = context.getBean(BookService.class);

        // Add a new book
        Book newBook = new Book();
        newBook.setTitle("Spring in Action");
        newBook.setAuthor("Craig Walls");
        newBook.setIsbn("978-1617294945");
        bookService.addBook(newBook);

        // Get a book by its ID
        Book retrievedBook = bookService.getBookById(newBook.getId());

        // Update the book
        retrievedBook.setAuthor("Craig Walls and Ryan Breidenbach");
        bookService.updateBook(retrievedBook);

        // Get all books
        bookService.getAllBooks();

        // Delete the book by its ID
        bookService.deleteBook(retrievedBook.getId());
    }
}
