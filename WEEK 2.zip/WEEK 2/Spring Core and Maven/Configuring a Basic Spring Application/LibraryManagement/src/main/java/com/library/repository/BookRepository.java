package com.library.repository;

public class BookRepository {
    public void printBookRepository() {
        System.out.println("Book Repository is working");
    }
}
