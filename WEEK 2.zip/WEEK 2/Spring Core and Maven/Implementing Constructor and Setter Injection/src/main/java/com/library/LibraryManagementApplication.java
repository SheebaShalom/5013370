package com.library;

import com.library.model.Book;
import com.library.service.BookService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class LibraryManagementApplication {

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        BookService bookService = context.getBean(BookService.class);

        // Add a new book
        Book newBook = new Book();
        newBook.setTitle("Spring in Action");
        newBook.setAuthor("Craig Walls");
        newBook.setIsbn("978-1617294945");
        bookService.addBook(newBook);
        System.out.println("Book added: " + newBook);

        // Get a book by its ID
        Book retrievedBook = bookService.getBookById(newBook.getId());
        System.out.println("Book retrieved: " + retrievedBook);

        // Update the book
        retrievedBook.setAuthor("Craig Walls and Ryan Breidenbach");
        bookService.updateBook(retrievedBook);
        System.out.println("Book updated: " + retrievedBook);

        // Get all books
        System.out.println("All books:");
        bookService.getAllBooks().forEach(System.out::println);

        // Delete the book by its ID
        bookService.deleteBook(retrievedBook.getId());
        System.out.println("Book deleted with ID: " + retrievedBook.getId());

        // Verify deletion
        System.out.println("All books after deletion:");
        bookService.getAllBooks().forEach(System.out::println);
    }
}
