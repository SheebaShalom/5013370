package com.library.service;

import com.library.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    private BookRepository bookRepository;

    // Constructor injection
    @Autowired
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Setter injection
    @Autowired
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Method to add a new book
    public void addBook(Book book) {
        bookRepository.save(book);
    }

    // Method to get a book by its ID
    public Book getBookById(Long id) {
        return bookRepository.findById(id).orElse(null);
    }

    // Method to get all books
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    // Method to update an existing book
    public void updateBook(Book book) {
        bookRepository.save(book);
    }

    // Method to delete a book by its ID
    public void deleteBook(Long id) {
        bookRepository.deleteById(id);
    }
}
