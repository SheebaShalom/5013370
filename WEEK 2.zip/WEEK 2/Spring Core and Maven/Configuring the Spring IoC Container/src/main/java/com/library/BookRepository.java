package com.library.repository;

public class BookRepository {

    public void save(String title) {
        // Simulate saving a book
        System.out.println("Saving book: " + title);
    }
}
