package com.example.bookstoreapi.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Version;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Entity
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonProperty("fullName")
    @NotNull
    @Size(min = 1, max = 100)
    private String name;

    @JsonProperty("email")
    @NotNull
    @Email
    @Size(min = 1, max = 100)
    private String email;

    @JsonProperty("phone")
    @NotNull
    @Size(min = 10, max = 15)
    private String phone;

    @Version
    private int version;
}
