package com.example.EmployeeManagementSystem.projection;

public class EmployeeProjectionDto {
    private Long id;
    private String name;

    public EmployeeProjectionDto(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    // Getters and setters
}
