package com.example.EmployeeManagementSystem.model;

import org.hibernate.annotations.Type;

@Entity
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "full_name")
    private String name;

    @Type(type = "org.hibernate.type.StringType")
    private String email;

    // Other fields and methods
}
