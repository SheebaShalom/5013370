package images;

public interface Image {
    void display();
}
