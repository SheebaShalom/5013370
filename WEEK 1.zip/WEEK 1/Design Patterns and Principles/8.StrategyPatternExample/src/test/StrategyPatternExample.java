package test;

import strategy.CreditCardPayment;
import strategy.PayPalPayment;
import strategy.PaymentContext;
import strategy.PaymentStrategy;

public class StrategyPatternExample {
    public static void main(String[] args) {
        PaymentContext context = new PaymentContext();

        // Pay using Credit Card
        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9876-5432", "John Doe");
        context.setPaymentStrategy(creditCardPayment);
        context.pay(150.0);

        // Pay using PayPal
        PaymentStrategy payPalPayment = new PayPalPayment("john.doe@example.com");
        context.setPaymentStrategy(payPalPayment);
        context.pay(200.0);
    }
}
