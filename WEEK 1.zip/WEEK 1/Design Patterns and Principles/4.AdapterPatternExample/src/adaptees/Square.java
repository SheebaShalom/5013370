package adaptees;

public class Square {
    public void pay(double amount) {
        System.out.println("Processing payment of $" + amount + " through Square.");
    }
}
