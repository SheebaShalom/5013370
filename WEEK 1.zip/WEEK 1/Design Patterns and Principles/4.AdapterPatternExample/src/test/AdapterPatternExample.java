package test;

import adapters.PayPalAdapter;
import adapters.StripeAdapter;
import adapters.SquareAdapter;
import adaptees.PayPal;
import adaptees.Stripe;
import adaptees.Square;
import interfaces.PaymentProcessor;

public class AdapterPatternExample {
    public static void main(String[] args) {
        // Creating instances of payment gateways
        PayPal payPal = new PayPal();
        Stripe stripe = new Stripe();
        Square square = new Square();

        // Creating adapters for each payment gateway
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPal);
        PaymentProcessor stripeAdapter = new StripeAdapter(stripe);
        PaymentProcessor squareAdapter = new SquareAdapter(square);

        // Using adapters to process payments
        payPalAdapter.processPayment(100.00);
        stripeAdapter.processPayment(200.00);
        squareAdapter.processPayment(300.00);
    }
}
