package repository;

import java.util.HashMap;
import java.util.Map;

public class CustomerRepositoryImpl implements CustomerRepository {
    private Map<String, String> customerDatabase = new HashMap<>();

    public CustomerRepositoryImpl() {
        // Adding some dummy data
        customerDatabase.put("1", "Sheeba");
        customerDatabase.put("2", "Shalom");
    }

    @Override
    public String findCustomerById(String id) {
        return customerDatabase.get(id);
    }
}
