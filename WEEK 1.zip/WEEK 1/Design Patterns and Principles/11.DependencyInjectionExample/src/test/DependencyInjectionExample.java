package test;

import repository.CustomerRepositoryImpl;
import service.CustomerService;

public class DependencyInjectionExample {
    public static void main(String[] args) {
        // Create a CustomerRepositoryImpl instance
        CustomerRepositoryImpl customerRepository = new CustomerRepositoryImpl();

        // Inject the repository into the service
        CustomerService customerService = new CustomerService(customerRepository);

        // Use the service to get customer details
        String customerId = "1";
        String customerDetails = customerService.getCustomerDetails(customerId);

        System.out.println("Customer Details: " + customerDetails);
    }
}
