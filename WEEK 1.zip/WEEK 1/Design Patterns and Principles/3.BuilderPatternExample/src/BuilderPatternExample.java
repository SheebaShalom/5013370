public class BuilderPatternExample {
    public static void main(String[] args) {
        // Creating different configurations of Computer using the Builder pattern

        // Basic configuration
        Computer basicComputer = new Computer.Builder()
                .setCPU("Intel i3")
                .setRAM("8GB")
                .setStorage("256GB SSD")
                .build();

        System.out.println("Basic Computer: CPU = " + basicComputer.getCPU() + ", RAM = " + basicComputer.getRAM() + ", Storage = " + basicComputer.getStorage());

        // Gaming configuration
        Computer gamingComputer = new Computer.Builder()
                .setCPU("Intel i9")
                .setRAM("32GB")
                .setStorage("1TB SSD")
                .setGPU("NVIDIA RTX 3080")
                .setMotherboard("Asus ROG")
                .setPowerSupply("750W")
                .build();

        System.out.println("Gaming Computer: CPU = " + gamingComputer.getCPU() + ", RAM = " + gamingComputer.getRAM() + ", Storage = " + gamingComputer.getStorage() + ", GPU = " + gamingComputer.getGPU() + ", Motherboard = " + gamingComputer.getMotherboard() + ", Power Supply = " + gamingComputer.getPowerSupply());

        // Workstation configuration
        Computer workstationComputer = new Computer.Builder()
                .setCPU("AMD Ryzen 9")
                .setRAM("64GB")
                .setStorage("2TB SSD")
                .setGPU("NVIDIA Quadro RTX 5000")
                .setMotherboard("MSI Pro")
                .setPowerSupply("850W")
                .build();

        System.out.println("Workstation Computer: CPU = " + workstationComputer.getCPU() + ", RAM = " + workstationComputer.getRAM() + ", Storage = " + workstationComputer.getStorage() + ", GPU = " + workstationComputer.getGPU() + ", Motherboard = " + workstationComputer.getMotherboard() + ", Power Supply = " + workstationComputer.getPowerSupply());
    }
}
