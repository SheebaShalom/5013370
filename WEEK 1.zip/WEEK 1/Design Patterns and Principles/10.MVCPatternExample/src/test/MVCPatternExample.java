package test;

import controller.StudentController;
import model.Student;
import view.StudentView;

public class MVCPatternExample {
    public static void main(String[] args) {
        // Create a Student model object
        Student model = new Student("1", "Sheeba", "A");

        // Create a StudentView object
        StudentView view = new StudentView();

        // Create a StudentController object
        StudentController controller = new StudentController(model, view);

        // Display initial student details
        controller.updateView();

        // Update student details
        controller.setStudentName("Shalom");
        controller.setStudentGrade("A+");

        // Display updated student details
        controller.updateView();
    }
}
