package test;

import notifiers.EmailNotifier;
import notifiers.Notifier;
import notifiers.SMSNotifierDecorator;
import notifiers.SlackNotifierDecorator;

public class DecoratorPatternExample {
    public static void main(String[] args) {
        Notifier notifier = new EmailNotifier();

        // Adding SMS notification
        notifier = new SMSNotifierDecorator(notifier);

        // Adding Slack notification
        notifier = new SlackNotifierDecorator(notifier);

        // Sending notifications
        notifier.send("Hello, this is a test notification.");
    }
}
