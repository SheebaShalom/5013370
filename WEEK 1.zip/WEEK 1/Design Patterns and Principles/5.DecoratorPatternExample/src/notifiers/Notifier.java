package notifiers;

public interface Notifier {
    void send(String message);
}
