public class Main {
    public static void main(String[] args) {
        EmployeeManagement management = new EmployeeManagement(5);

        // Add employees
        management.addEmployee(new Employee("E001", "Sheeba", "Manager", 75000));
        management.addEmployee(new Employee("E002", "Shalom", "Developer", 60000));
        management.addEmployee(new Employee("E003", "Daniya", "Designer", 50000));

        // Traverse employees
        System.out.println("All Employees:");
        management.traverseEmployees();

        // Search for an employee
        Employee emp = management.searchEmployeeById("E002");
        System.out.println("\nSearched Employee: " + emp);

        // Delete an employee
        boolean deleted = management.deleteEmployeeById("E002");
        System.out.println("\nEmployee E002 deleted: " + deleted);

        // Traverse employees after deletion
        System.out.println("\nAll Employees after deletion:");
        management.traverseEmployees();
    }
}
