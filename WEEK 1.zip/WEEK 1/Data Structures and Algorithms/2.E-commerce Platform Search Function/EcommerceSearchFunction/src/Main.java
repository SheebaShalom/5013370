import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Product[] products = {
                new Product("P001", "Laptop", "Electronics"),
                new Product("P002", "Smartphone", "Electronics"),
                new Product("P003", "Tablet", "Electronics"),
                new Product("P004", "Headphones", "Accessories"),
                new Product("P005", "Charger", "Accessories")
        };

        // Linear search
        Product result1 = Search.linearSearch(products, "Tablet");
        System.out.println("Linear Search Result: " + result1);

        // Sort array for binary search
        Arrays.sort(products, (a, b) -> a.getProductName().compareToIgnoreCase(b.getProductName()));

        // Binary search
        Product result2 = Search.binarySearch(products, "Tablet");
        System.out.println("Binary Search Result: " + result2);
    }
}
