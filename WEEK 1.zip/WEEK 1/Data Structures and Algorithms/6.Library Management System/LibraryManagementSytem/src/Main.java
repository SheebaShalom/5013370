public class Main {
    public static void main(String[] args) {
        // Create some books
        Book[] books = {
                new Book("B003", "Java Programming", "John Doe"),
                new Book("B001", "Data Structures", "Jane Smith"),
                new Book("B002", "Algorithms", "Alice Johnson")
        };

        // Initialize LibraryManagement with unsorted books
        LibraryManagement library = new LibraryManagement(books);

        // Linear search example
        Book result = library.linearSearchByTitle("Algorithms");
        System.out.println("Linear Search Result: " + result);

        // Sort books and binary search example
        library.sortBooksByTitle();
        result = library.binarySearchByTitle("Algorithms");
        System.out.println("Binary Search Result: " + result);
    }
}
