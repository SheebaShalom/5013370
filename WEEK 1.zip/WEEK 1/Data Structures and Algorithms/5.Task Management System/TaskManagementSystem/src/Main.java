public class Main {
    public static void main(String[] args) {
        SinglyLinkedList taskList = new SinglyLinkedList();

        // Add tasks
        taskList.addTask(new Task("T001", "Design Homepage", "In Progress"));
        taskList.addTask(new Task("T002", "Develop Backend", "Not Started"));
        taskList.addTask(new Task("T003", "Write Documentation", "Completed"));

        // Traverse tasks
        System.out.println("All Tasks:");
        taskList.traverseTasks();

        // Search for a task
        Task task = taskList.searchTaskById("T002");
        System.out.println("\nSearched Task: " + task);

        // Delete a task
        boolean deleted = taskList.deleteTaskById("T002");
        System.out.println("\nTask T002 deleted: " + deleted);

        // Traverse tasks after deletion
        System.out.println("\nAll Tasks after deletion:");
        taskList.traverseTasks();
    }
}
